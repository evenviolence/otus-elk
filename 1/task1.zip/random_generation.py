#!/usr/bin/python3.6

import random

random.seed()
print(random.randint(0,100))
